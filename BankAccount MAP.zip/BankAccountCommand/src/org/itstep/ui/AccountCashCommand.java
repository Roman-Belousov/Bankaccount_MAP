package org.itstep.ui;

public class AccountCashCommand extends BankAccountCommand {

	@Override
	public void exec(String[] args) {
		
		if (args.length == 2) {
			int accountId1 = Integer.valueOf(args[0]);
			int transfersumm = Integer.valueOf(args[1]);
			getAccountService().cash(accountId1, transfersumm);
		
	} else {
		System.out.println("Неверное количество аргументов!");
	}
	}
}
