package org.itstep.ui;


public interface Command {
	void exec(String args[]);
}