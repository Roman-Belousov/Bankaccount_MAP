package org.itstep;


import org.itstep.ui.BankAccountCommand;

public class AccountSelectCommand extends BankAccountCommand{

	@Override
	public void exec(String[] args) {
		if (args.length == 1) {
			Integer accountnumber = Integer.valueOf(args[0]);
			getAccountService().select(accountnumber);
			

	} else {
		System.out.println("Неверное количество аргументов!");
	}
	}
}

		
	


