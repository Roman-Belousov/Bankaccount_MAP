package org.itstep.ui;

public class ExitCommand implements Command {
	@Override
	public void exec(String[] args) {
		System.out.println("Сеанс работы со счетами окончен! Всего доброго!");
		System.exit(0);
	}
}