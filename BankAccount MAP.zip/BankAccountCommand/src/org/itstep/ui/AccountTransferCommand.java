package org.itstep.ui;

public class AccountTransferCommand extends BankAccountCommand {

	@Override
	public void exec(String[] args) {
		
		if (args.length == 3) {
			int accountId1 = Integer.valueOf(args[0]);
			int accountId2 = Integer.valueOf(args[1]);
			int transfersumm = Integer.valueOf(args[2]);
			getAccountService().transfer(accountId1, accountId2, transfersumm);
		
	} else {
		System.out.println("Неверное количество аргументов!");
	}
	}
}
