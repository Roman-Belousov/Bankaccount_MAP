package org.itstep.ui;

import org.itstep.logic.AccountService;

abstract public class BankAccountCommand implements Command {
	public AccountService accountService;

	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}

	public AccountService getAccountService() {
		return accountService;
	}
}