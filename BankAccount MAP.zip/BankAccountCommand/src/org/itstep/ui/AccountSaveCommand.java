package org.itstep.ui;

import org.itstep.domain.Bankaccount.Bankaccount;

public class AccountSaveCommand extends BankAccountCommand {
	@Override
	public void exec(String[] args) {
		if (args.length == 2) {

			Bankaccount bankaccount = new Bankaccount();
			Integer offset = 0;
			if (args.length == 2) {
				bankaccount.setAccountnumber(Integer.valueOf(args[0]));
				offset = 1;
				
			}
				bankaccount.setAccountbalance(Integer.valueOf(args[offset]));
				getAccountService().save(bankaccount);
				System.out.println("Счет успешно сохранен!");
				
			

		} else {
			System.out.println("Неверное количество аргументов!");
		}
	}
}
