package org.itstep.ui;

import java.util.Map;

import org.itstep.domain.Bankaccount.Bankaccount;

public class AccountListCommand extends BankAccountCommand {
	@Override
	public void exec(String[] args) {
		Map<Integer, Bankaccount> bankaccounts = getAccountService().findAll();
		if (!bankaccounts.isEmpty()) {
			for (Map.Entry<Integer, Bankaccount> entry : bankaccounts.entrySet()) {
				System.out.println(entry.getValue());
			}

		} else {

			System.out.println("Список счетов пуст!");

		}
	}
}
