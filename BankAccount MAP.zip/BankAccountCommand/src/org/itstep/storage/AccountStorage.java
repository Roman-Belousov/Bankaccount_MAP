package org.itstep.storage;


import java.util.Map;

import org.itstep.domain.Bankaccount.Bankaccount;

public interface AccountStorage {

	Integer create(Bankaccount bankaccount);

	Bankaccount read(Integer accountnumber);

	Map<Integer,Bankaccount> read();

	void update(Bankaccount bankaccount);

	void delete(Integer accountnumber);
	


}
