package org.itstep.storage;

import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;

import org.itstep.domain.Bankaccount.Bankaccount;

public class AccountMemoryStorageImpl implements AccountStorage {
	private Map<Integer, Bankaccount> bankaccounts = new TreeMap<>();

	@Override
	public Integer create(Bankaccount bankaccount) {
		Integer accountnumber;
		if (!bankaccounts.isEmpty()) {
			accountnumber = Collections.max(bankaccounts.keySet());
		} else {
			accountnumber = 0;
		}
		accountnumber++;
		bankaccount.setAccountnumber(accountnumber);
		bankaccounts.put(accountnumber, bankaccount);
		return accountnumber;

	}

	@Override
	public Bankaccount read(Integer accountnumber) {
		for (Map.Entry<Integer, Bankaccount> entry : bankaccounts.entrySet()) {
			if (bankaccounts.get(entry.getKey()).getAccountnumber().equals(accountnumber)) {

				return bankaccounts.get(entry.getKey());
			}
		}
		return null;
	}

	@Override
	public Map<Integer, Bankaccount> read() {
		return bankaccounts;

	}

	@Override
	public void update(Bankaccount bankaccount) {
		bankaccounts.put(bankaccount.getAccountnumber(), bankaccount);
	}

	@Override
	public void delete(Integer accountnumber) {
		bankaccounts.remove(accountnumber);
	}
}
